#!/usr/bin/env python
from flask_app import app
app.run(debug = True)
